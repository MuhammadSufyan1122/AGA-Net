"""
Inference script for AGA-Net.
Usage:
    python inference.py --checkpoint checkpoints/aga_net_final.pt \
                        --input_npy /path/to/patch.npy

Outputs:
    - Segmentation mask (.npy)
    - Malignancy probability + uncertainty
    - Visualisation PNG (optional)
"""

import os
import sys
import argparse
import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from models.aga_net import AGANet


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--checkpoint',   type=str, required=True)
    p.add_argument('--input_npy',    type=str, default=None,
                   help='Path to .npy CT patch (H,W,D)')
    p.add_argument('--output_dir',   type=str, default='./inference_out')
    p.add_argument('--device',       type=str, default='auto')
    p.add_argument('--mc_samples',   type=int, default=50)
    p.add_argument('--seg_threshold',type=float, default=0.5)
    p.add_argument('--visualise',    action='store_true')
    p.add_argument('--base_filters', type=int, default=32)
    p.add_argument('--num_classes',  type=int, default=2)
    return p.parse_args()


@torch.no_grad()
def run_inference(model, volume: np.ndarray, device: torch.device,
                  mc_samples: int = 50, seg_thresh: float = 0.5) -> dict:
    """
    Run full AGA-Net inference on a single 3-D patch.
    volume: (H,W,D) float32, HU-clipped & z-score normalised
    """
    model.eval()
    model.to(device)

    x = torch.from_numpy(volume).unsqueeze(0).unsqueeze(0).to(device)  # (1,1,H,W,D)

    # Segmentation (Stage 1)
    seg_logits, seg_prob = model.seg_net(x)
    seg_mask = (seg_prob > seg_thresh).squeeze().cpu().numpy().astype(np.uint8)

    # Classification + Uncertainty (Stage 2)
    nodule_crop = x * (seg_prob > 0.5).float()
    cls_out = model.muq_net(nodule_crop, mc_samples=mc_samples)

    probs = cls_out['probs'].squeeze().cpu().numpy()
    unc   = cls_out['uncertainty'].cpu().item()
    label = int(probs.argmax())

    if 'epistemic_var' in cls_out:
        epist = cls_out['epistemic_var'].mean().cpu().item()
        aleat = cls_out['log_var'].exp().mean().cpu().item()
    else:
        epist = unc
        aleat = cls_out['log_var'].exp().mean().cpu().item()

    return {
        'seg_mask':        seg_mask,
        'seg_prob':        seg_prob.squeeze().cpu().numpy(),
        'malignancy_prob': float(probs[1]) if len(probs) > 1 else float(probs[0]),
        'predicted_class': label,
        'class_probs':     probs.tolist(),
        'uncertainty':     float(unc),
        'epistemic_var':   float(epist),
        'aleatoric_var':   float(aleat),
        'clinical_zone':   clinical_triage(float(probs[1]) if len(probs) > 1 else 0.5, float(unc))
    }


def clinical_triage(p_malignant: float, uncertainty: float) -> str:
    """
    Three-zone clinical decision support:
    - auto-accept:      low uncertainty + benign
    - radiologist review: moderate uncertainty or borderline
    - priority referral: high malignancy or high uncertainty
    """
    if p_malignant > 0.70 or uncertainty > 0.20:
        return 'PRIORITY_REFERRAL'
    elif p_malignant < 0.15 and uncertainty < 0.05:
        return 'AUTO_ACCEPT_BENIGN'
    else:
        return 'RADIOLOGIST_REVIEW'


def visualise_results(volume: np.ndarray, results: dict,
                       output_path: str) -> None:
    """Save multi-panel visualisation of segmentation and uncertainty"""
    try:
        import matplotlib.pyplot as plt
        import matplotlib.gridspec as gridspec
    except ImportError:
        print("  matplotlib not available — skipping visualisation")
        return

    H, W, D = volume.shape
    mid_z   = H // 2

    fig = plt.figure(figsize=(18, 5))
    gs  = gridspec.GridSpec(1, 5, wspace=0.3)

    # Panel 1: CT slice
    ax = fig.add_subplot(gs[0])
    ax.imshow(volume[mid_z], cmap='gray')
    ax.set_title('CT Patch (axial)')
    ax.axis('off')

    # Panel 2: Segmentation probability
    ax = fig.add_subplot(gs[1])
    im = ax.imshow(results['seg_prob'][mid_z], cmap='hot', vmin=0, vmax=1)
    plt.colorbar(im, ax=ax, fraction=0.046)
    ax.set_title('Seg Probability')
    ax.axis('off')

    # Panel 3: Binary mask
    ax = fig.add_subplot(gs[2])
    ax.imshow(volume[mid_z], cmap='gray')
    mask_overlay = np.zeros((*volume[mid_z].shape, 4))
    mask_overlay[results['seg_mask'][mid_z] == 1] = [1, 0, 0, 0.5]
    ax.imshow(mask_overlay)
    ax.set_title('Segmentation Mask')
    ax.axis('off')

    # Panel 4: Classification bar chart
    ax = fig.add_subplot(gs[3])
    classes = ['Benign', 'Malignant']
    colours = ['#2196F3', '#F44336']
    bars = ax.bar(classes, results['class_probs'][:2], color=colours, width=0.4)
    ax.set_ylim(0, 1)
    ax.set_ylabel('Probability')
    ax.set_title('Classification')
    for bar, val in zip(bars, results['class_probs'][:2]):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
                f'{val:.3f}', ha='center', fontsize=10)

    # Panel 5: Uncertainty breakdown
    ax = fig.add_subplot(gs[4])
    unc_types = ['Total', 'Epistemic', 'Aleatoric']
    unc_vals  = [results['uncertainty'],
                 results['epistemic_var'],
                 results['aleatoric_var']]
    colours2  = ['#9C27B0', '#FF9800', '#4CAF50']
    ax.bar(unc_types, unc_vals, color=colours2, width=0.5)
    ax.set_ylabel('Variance')
    ax.set_title('Uncertainty')
    plt.xticks(rotation=15)

    # Title
    zone  = results['clinical_zone'].replace('_', ' ')
    p_mal = results['malignancy_prob']
    fig.suptitle(
        f"AGA-Net Inference  |  Clinical Zone: {zone}  |  "
        f"P(malignant)={p_mal:.3f}  |  Uncertainty={results['uncertainty']:.4f}",
        fontsize=12, fontweight='bold'
    )

    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    print(f"  Visualisation saved → {output_path}")


def main():
    args = parse_args()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') \
             if args.device == 'auto' else torch.device(args.device)
    print(f"[Device] {device}")

    # Load model
    print(f"[Model] Loading from {args.checkpoint}")
    model = AGANet(in_channels=1, num_classes=args.num_classes,
                   base_filters=args.base_filters,
                   mc_samples=args.mc_samples)

    ckpt = torch.load(args.checkpoint, map_location=device)
    state = ckpt.get('model_state', ckpt)
    model.load_state_dict(state, strict=False)
    print("  ✓ Model loaded")

    # Load input or generate synthetic
    if args.input_npy and os.path.exists(args.input_npy):
        volume = np.load(args.input_npy).astype(np.float32)
        print(f"[Input] Loaded patch shape: {volume.shape}")
    else:
        print("[Input] No input provided — using synthetic nodule patch")
        H, W, D = 64, 64, 64
        volume = np.random.randn(H, W, D).astype(np.float32) * 0.1 - 0.5
        zz, yy, xx = np.mgrid[:H, :W, :D]
        dist = np.sqrt((zz-32)**2 + (yy-32)**2 + (xx-32)**2)
        volume += (dist < 8).astype(np.float32) * 0.8

    # Normalise
    volume = np.clip(volume, -1000, 400)
    volume = (volume - volume.mean()) / (volume.std() + 1e-6)

    # Run inference
    print(f"[Inference] Running with {args.mc_samples} MC samples...")
    results = run_inference(model, volume, device,
                             mc_samples=args.mc_samples,
                             seg_thresh=args.seg_threshold)

    # Print results
    print("\n" + "="*50)
    print("  INFERENCE RESULTS")
    print("="*50)
    print(f"  Predicted Class:   {'Malignant' if results['predicted_class'] == 1 else 'Benign'}")
    print(f"  P(malignant):      {results['malignancy_prob']:.4f}")
    print(f"  Class Probs:       {[f'{p:.4f}' for p in results['class_probs']]}")
    print(f"  Total Uncertainty: {results['uncertainty']:.4f}")
    print(f"  Epistemic Var:     {results['epistemic_var']:.4f}")
    print(f"  Aleatoric Var:     {results['aleatoric_var']:.4f}")
    print(f"  Clinical Zone:     {results['clinical_zone']}")
    print(f"  Nodule voxels:     {results['seg_mask'].sum()}")

    # Save outputs
    os.makedirs(args.output_dir, exist_ok=True)
    np.save(os.path.join(args.output_dir, 'seg_mask.npy'),
            results['seg_mask'])
    np.save(os.path.join(args.output_dir, 'seg_prob.npy'),
            results['seg_prob'])

    import json
    summary = {k: v for k, v in results.items()
               if not isinstance(v, np.ndarray)}
    with open(os.path.join(args.output_dir, 'results.json'), 'w') as fh:
        json.dump(summary, fh, indent=2)

    if args.visualise:
        vis_path = os.path.join(args.output_dir, 'visualisation.png')
        visualise_results(volume, results, vis_path)

    print(f"\n[Output] Results saved → {args.output_dir}")


if __name__ == '__main__':
    main()
