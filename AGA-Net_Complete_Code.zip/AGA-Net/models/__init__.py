# models/__init__.py
from .aga_net import AGANet, GCAM, SegmentationNetwork, MUQNet
