# losses/__init__.py
from .aga_losses import (AGANetLoss, SegmentationLoss, ClassificationLoss,
                          UncertaintyLoss, FederatedRegularizationLoss,
                          AdaptiveLossWeighter)
