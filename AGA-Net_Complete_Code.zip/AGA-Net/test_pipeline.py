"""
Quick smoke test — verifies the complete pipeline runs end-to-end
without real data. Run before your full training job.

Usage:
    python test_pipeline.py
"""

import sys
import os
import torch
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def test_model_forward():
    print("\n[TEST 1] Model forward pass...")
    from models.aga_net import AGANet
    model = AGANet(in_channels=1, num_classes=2,
                   base_filters=16, dropout_p=0.3, mc_samples=5)
    x = torch.randn(2, 1, 32, 32, 32)   # small batch for speed
    out = model(x, return_uncertainty=True)

    assert 'seg_logits' in out,  "Missing seg_logits"
    assert 'seg_prob'   in out,  "Missing seg_prob"
    assert 'cls_probs'  in out,  "Missing cls_probs"
    assert out['seg_logits'].shape == x.shape, "Seg shape mismatch"
    assert out['cls_probs'].shape  == (2, 2),  "Cls shape mismatch"
    print("  ✓ Forward pass OK")


def test_losses():
    print("\n[TEST 2] Loss computation...")
    from models.aga_net  import AGANet
    from losses.aga_losses import AGANetLoss

    model   = AGANet(in_channels=1, num_classes=2,
                     base_filters=16, dropout_p=0.3, mc_samples=1)
    loss_fn = AGANetLoss(num_classes=2, adaptive=True)

    x      = torch.randn(2, 1, 32, 32, 32)
    masks  = torch.randint(0, 2, (2, 1, 32, 32, 32)).float()
    labels = torch.randint(0, 2, (2,))

    out  = model(x, return_uncertainty=False)
    lps  = list(model.parameters())
    gps  = [p.clone().detach() for p in lps]

    ld = loss_fn(out, masks, labels,
                 local_params=lps, global_params=gps)
    assert ld['total'].item() > 0, "Total loss should be > 0"
    print(f"  ✓ Losses: total={ld['total'].item():.4f}  "
          f"seg={ld['seg'].item():.4f}  cls={ld['cls'].item():.4f}")


def test_federated_partitioning():
    print("\n[TEST 3] Federated data partitioning...")
    from data.dataset import SyntheticNoduleDataset, build_federated_loaders

    ds      = SyntheticNoduleDataset(n_samples=100, patch_size=(16,16,16))
    loaders = build_federated_loaders(ds, num_clients=4,
                                      alpha_dir=0.5, batch_size=4)
    assert len(loaders) == 4, "Expected 4 client loaders"
    total = sum(len(l.dataset) for l in loaders)
    assert total == 100, f"Expected 100 total, got {total}"
    print(f"  ✓ 4 clients, sizes: {[len(l.dataset) for l in loaders]}")


def test_metrics():
    print("\n[TEST 4] Metric computation...")
    from utils.metrics import (compute_segmentation_metrics,
                                compute_classification_metrics)

    N = 10; H = W = D = 16
    pred_probs = np.random.rand(N, H, W, D)
    targets    = (np.random.rand(N, H, W, D) > 0.5).astype(float)
    seg_m = compute_segmentation_metrics(pred_probs, targets)
    assert 'DSC' in seg_m
    print(f"  ✓ Seg metrics: DSC={seg_m['DSC']:.4f}")

    cls_probs = np.random.dirichlet([1,1], N)
    cls_labels = np.random.randint(0, 2, N)
    cls_m = compute_classification_metrics(cls_probs, cls_labels)
    assert 'AUC' in cls_m
    print(f"  ✓ Cls metrics: AUC={cls_m['AUC']:.4f}  ECE={cls_m['ECE']:.4f}")


def test_mini_federated_training():
    print("\n[TEST 5] Mini federated training (3 rounds)...")
    from models.aga_net  import AGANet
    from losses.aga_losses import AGANetLoss
    from data.dataset    import SyntheticNoduleDataset, build_federated_loaders, build_eval_loader
    from federated.fl_trainer import FederatedServer

    device = torch.device('cpu')
    model  = AGANet(in_channels=1, num_classes=2,
                    base_filters=8, dropout_p=0.3, mc_samples=2)
    loss_fn = AGANetLoss(num_classes=2, adaptive=True)

    ds = SyntheticNoduleDataset(n_samples=40, patch_size=(16,16,16))
    client_loaders = build_federated_loaders(ds, num_clients=4,
                                              alpha_dir=1.0, batch_size=4)
    val_loader = build_eval_loader(
        SyntheticNoduleDataset(n_samples=10, patch_size=(16,16,16)),
        batch_size=4
    )

    server = FederatedServer(
        global_model    = model,
        loss_fn         = loss_fn,
        client_loaders  = client_loaders,
        val_loader      = val_loader,
        device          = device,
        num_rounds      = 3,
        local_epochs    = 1,
        client_fraction = 0.5,
        min_clients     = 2,
        local_lr        = 1e-3,
        use_dp          = True,
        epsilon         = 8.0,
        delta           = 1e-5,
        clip_bound      = 2.0,
        log_every       = 1,
        checkpoint_dir  = '/tmp/aga_test_ckpt'
    )

    history = server.train()
    assert len(history['round']) == 3
    print("  ✓ 3 federated rounds completed successfully")


def test_inference():
    print("\n[TEST 6] Inference pipeline...")
    from models.aga_net import AGANet
    from inference import run_inference

    device = torch.device('cpu')
    model  = AGANet(in_channels=1, num_classes=2,
                    base_filters=8, dropout_p=0.3, mc_samples=5)
    model.eval()

    vol = np.random.randn(32, 32, 32).astype(np.float32)
    out = run_inference(model, vol, device, mc_samples=5)

    assert 'seg_mask'  in out
    assert 'malignancy_prob' in out
    assert 'clinical_zone'   in out
    print(f"  ✓ Inference OK | P(mal)={out['malignancy_prob']:.4f} "
          f"| Zone={out['clinical_zone']}")


if __name__ == '__main__':
    tests = [
        test_model_forward,
        test_losses,
        test_federated_partitioning,
        test_metrics,
        test_mini_federated_training,
        test_inference,
    ]
    passed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"  ✗ FAILED: {e}")

    print(f"\n{'='*40}")
    print(f"  Tests passed: {passed}/{len(tests)}")
    print(f"{'='*40}\n")
    sys.exit(0 if passed == len(tests) else 1)
