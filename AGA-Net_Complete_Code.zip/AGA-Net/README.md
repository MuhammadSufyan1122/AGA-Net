# AGA-Net: Adaptive Geometric-Attention Network

Two-Stage Lung Nodule Segmentation and Malignancy Classification  
in Federated Healthcare IoT Systems

## Quick Start

### Install dependencies
```bash
pip install -r requirements.txt
```

### Run smoke tests (no data required)
```bash
python test_pipeline.py
```

### Train with synthetic data
```bash
python train.py --dataset synthetic --n_synthetic 400 \
                --num_clients 8 --rounds 100 --local_epochs 5
```

### Train with LUNA16
```bash
python train.py --dataset luna16 --data_dir /data/luna16 \
                --num_clients 8 --rounds 100 --epsilon 8.0
```

### Inference on a single patch
```bash
python inference.py --checkpoint checkpoints/aga_net_final.pt \
                    --input_npy /path/to/patch.npy \
                    --mc_samples 50 --visualise
```

## Repository Structure

```
AGA-Net/
├── models/
│   └── aga_net.py          # Full model: GCAM + SegNet + MUQ-Net
├── losses/
│   └── aga_losses.py       # All loss functions + adaptive weighter
├── data/
│   └── dataset.py          # Dataset classes + federated partitioning
├── federated/
│   └── fl_trainer.py       # Federated server + client trainer
├── utils/
│   └── metrics.py          # Segmentation + classification metrics
├── train.py                # Main training script
├── inference.py            # Inference + visualisation
└── test_pipeline.py        # Smoke tests
```

## Key Components

| Component | Description | Paper Section |
|-----------|-------------|---------------|
| `GCAM` | Geometric-Constrained Attention Module | Eq. 1–13 |
| `SegmentationNetwork` | 3-D U-Net with GCAM at each decoder level | Sec. 3.2 |
| `MUQNet` | MC Dropout + Deep Ensemble classifier | Eq. 14–20 |
| `AGANetLoss` | Dice+Focal+CE+Uncertainty+Federated loss | Eq. 21–34 |
| `FederatedServer` | FedAvg/FedProx/SCAFFOLD orchestrator | Alg. 1–2 |
| `dirichlet_partition` | Non-IID client partitioning | Eq. 35 |

## Datasets

- **LUNA16**: https://luna16.grand-challenge.org/
- **LIDC-IDRI**: https://www.cancerimagingarchive.net/collection/lidc-idri/
- **NSCLC-Radiomics**: https://www.cancerimagingarchive.net/collection/nsclc-radiomics/

Pre-process to 64×64×64 `.npy` patches with HU range [-1000, 400].
