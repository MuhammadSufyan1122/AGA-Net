"""
Evaluation metrics for AGA-Net.
Segmentation: DSC, IoU, HD95, ASD, Sensitivity, Specificity
Classification: AUC, Accuracy, Sensitivity, Specificity, F1, ECE, Brier
"""

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from sklearn.metrics import (roc_auc_score, accuracy_score, f1_score,
                             confusion_matrix, brier_score_loss,
                             average_precision_score)
from scipy.spatial.distance import directed_hausdorff
from typing import Dict, Tuple, Optional
import warnings


# ─────────────────────────────────────────────────────────────
# Segmentation Metrics
# ─────────────────────────────────────────────────────────────

def dice_coefficient(pred: np.ndarray,
                     target: np.ndarray,
                     smooth: float = 1e-5) -> float:
    """DSC = 2|P∩G| / (|P| + |G|)"""
    p = pred.flatten()
    g = target.flatten()
    return (2.0 * (p * g).sum() + smooth) / \
           (p.sum() + g.sum() + smooth)


def iou_score(pred: np.ndarray,
              target: np.ndarray,
              smooth: float = 1e-5) -> float:
    """IoU = |P∩G| / |P∪G|"""
    p = (pred > 0.5).flatten()
    g = (target > 0.5).flatten()
    inter = (p & g).sum()
    union = (p | g).sum()
    return (inter + smooth) / (union + smooth)


def hausdorff_95(pred: np.ndarray,
                 target: np.ndarray) -> float:
    """95th-percentile Hausdorff Distance (HD95)"""
    p_pts = np.argwhere(pred > 0.5)
    g_pts = np.argwhere(target > 0.5)

    if len(p_pts) == 0 or len(g_pts) == 0:
        return float('inf')

    # Sub-sample for speed on large volumes
    if len(p_pts) > 5000:
        idx = np.random.choice(len(p_pts), 5000, replace=False)
        p_pts = p_pts[idx]
    if len(g_pts) > 5000:
        idx = np.random.choice(len(g_pts), 5000, replace=False)
        g_pts = g_pts[idx]

    from scipy.spatial import cKDTree
    tree_g = cKDTree(g_pts)
    tree_p = cKDTree(p_pts)

    d_pg, _ = tree_g.query(p_pts)
    d_gp, _ = tree_p.query(g_pts)

    return float(np.percentile(np.concatenate([d_pg, d_gp]), 95))


def average_surface_distance(pred: np.ndarray,
                              target: np.ndarray) -> float:
    """Average Surface Distance (ASD)"""
    p_pts = np.argwhere(pred > 0.5)
    g_pts = np.argwhere(target > 0.5)

    if len(p_pts) == 0 or len(g_pts) == 0:
        return float('inf')

    if len(p_pts) > 5000:
        p_pts = p_pts[np.random.choice(len(p_pts), 5000, replace=False)]
    if len(g_pts) > 5000:
        g_pts = g_pts[np.random.choice(len(g_pts), 5000, replace=False)]

    from scipy.spatial import cKDTree
    d_pg = cKDTree(g_pts).query(p_pts)[0].mean()
    d_gp = cKDTree(p_pts).query(g_pts)[0].mean()
    return float((d_pg + d_gp) / 2.0)


def seg_sensitivity_specificity(pred: np.ndarray,
                                 target: np.ndarray
                                 ) -> Tuple[float, float]:
    """Voxel-level sensitivity and specificity"""
    p = (pred > 0.5).flatten().astype(bool)
    g = target.flatten().astype(bool)
    tp = (p & g).sum()
    tn = (~p & ~g).sum()
    fp = (p & ~g).sum()
    fn = (~p & g).sum()
    sens = tp / max(tp + fn, 1)
    spec = tn / max(tn + fp, 1)
    return float(sens), float(spec)


def compute_segmentation_metrics(pred_probs: np.ndarray,
                                  targets: np.ndarray) -> Dict:
    """
    Compute all segmentation metrics for a batch.
    pred_probs: (N, H, W, D) float in [0,1]
    targets:    (N, H, W, D) binary
    """
    results = {k: [] for k in
               ['DSC', 'IoU', 'HD95', 'ASD', 'Sens', 'Spec']}

    for pred, tgt in zip(pred_probs, targets):
        results['DSC'].append(dice_coefficient(pred, tgt))
        results['IoU'].append(iou_score(pred, tgt))
        results['Sens'].append(seg_sensitivity_specificity(pred, tgt)[0])
        results['Spec'].append(seg_sensitivity_specificity(pred, tgt)[1])
        try:
            results['HD95'].append(hausdorff_95(pred, tgt))
            results['ASD'].append(average_surface_distance(pred, tgt))
        except Exception:
            results['HD95'].append(float('nan'))
            results['ASD'].append(float('nan'))

    return {k: float(np.nanmean(v)) for k, v in results.items()}


# ─────────────────────────────────────────────────────────────
# Classification Metrics
# ─────────────────────────────────────────────────────────────

def expected_calibration_error(probs: np.ndarray,
                                labels: np.ndarray,
                                n_bins: int = 10) -> float:
    """
    Expected Calibration Error (ECE) — Eq. 29.
    probs:  (N, C) predicted probabilities
    labels: (N,) ground truth class indices
    """
    confidences = probs.max(axis=1)
    predictions = probs.argmax(axis=1)
    corrects    = (predictions == labels).astype(float)

    bins = np.linspace(0, 1, n_bins + 1)
    ece  = 0.0
    n    = len(labels)

    for i in range(n_bins):
        lo, hi = bins[i], bins[i+1]
        mask = (confidences >= lo) & (confidences < hi)
        if mask.sum() == 0:
            continue
        acc  = corrects[mask].mean()
        conf = confidences[mask].mean()
        ece += (mask.sum() / n) * abs(acc - conf)

    return float(ece)


def compute_classification_metrics(probs: np.ndarray,
                                    labels: np.ndarray,
                                    uncertainties: Optional[np.ndarray] = None
                                    ) -> Dict:
    """
    Compute all classification metrics.
    probs:  (N, C)
    labels: (N,)
    """
    preds = probs.argmax(axis=1)
    n_cls = probs.shape[1]

    metrics = {}

    # AUC (binary or multi-class)
    try:
        if n_cls == 2:
            metrics['AUC'] = float(roc_auc_score(labels, probs[:, 1]))
        else:
            metrics['AUC'] = float(roc_auc_score(
                labels, probs, multi_class='ovr', average='macro'))
    except Exception:
        metrics['AUC'] = float('nan')

    # Standard metrics
    metrics['Acc']  = float(accuracy_score(labels, preds))
    metrics['F1']   = float(f1_score(labels, preds, average='macro',
                                      zero_division=0))

    # Confusion matrix → Sensitivity, Specificity (binary)
    if n_cls == 2:
        cm = confusion_matrix(labels, preds, labels=[0, 1])
        tn, fp, fn, tp = cm.ravel() if cm.shape == (2,2) else (0,0,0,0)
        metrics['Sens'] = float(tp / max(tp + fn, 1))
        metrics['Spec'] = float(tn / max(tn + fp, 1))
        metrics['Brier'] = float(brier_score_loss(
            labels, probs[:, 1], pos_label=1))
        try:
            metrics['AUPR'] = float(average_precision_score(
                labels, probs[:, 1]))
        except Exception:
            metrics['AUPR'] = float('nan')

    # Calibration
    metrics['ECE'] = expected_calibration_error(probs, labels)

    # Uncertainty statistics
    if uncertainties is not None:
        metrics['UncMean'] = float(uncertainties.mean())
        metrics['UncStd']  = float(uncertainties.std())

    return metrics


# ─────────────────────────────────────────────────────────────
# Full Model Evaluation
# ─────────────────────────────────────────────────────────────

@torch.no_grad()
def evaluate_model(model,
                   loader: DataLoader,
                   device: torch.device,
                   mc_samples: int = 50) -> Dict:
    """
    Run full evaluation on a DataLoader.
    Returns combined segmentation + classification metrics.
    """
    model.eval()
    model.to(device)

    all_seg_probs   = []
    all_seg_targets = []
    all_cls_probs   = []
    all_cls_targets = []
    all_uncertainties = []

    for batch in loader:
        images = batch['image'].to(device)
        masks  = batch['mask'].to(device)
        labels = batch['label'].to(device)

        output = model(images, return_uncertainty=(mc_samples > 1))

        seg_p = output['seg_prob'].cpu().numpy()[:, 0]  # (B,H,W,D)
        mask_ = masks.cpu().numpy()[:, 0]

        cls_p = output['cls_probs'].cpu().numpy()       # (B,C)
        unc_  = output.get('cls_uncertainty',
                           output.get('cls_log_var',
                                      torch.zeros(images.shape[0]))).cpu()
        if isinstance(unc_, torch.Tensor):
            unc_ = unc_.numpy()

        all_seg_probs.append(seg_p)
        all_seg_targets.append(mask_)
        all_cls_probs.append(cls_p)
        all_cls_targets.append(labels.cpu().numpy())
        all_uncertainties.append(np.atleast_1d(unc_))

    all_seg_probs   = np.concatenate(all_seg_probs, axis=0)
    all_seg_targets = np.concatenate(all_seg_targets, axis=0)
    all_cls_probs   = np.concatenate(all_cls_probs, axis=0)
    all_cls_targets = np.concatenate(all_cls_targets, axis=0)
    all_unc         = np.concatenate(all_uncertainties, axis=0)

    seg_metrics = compute_segmentation_metrics(all_seg_probs, all_seg_targets)
    cls_metrics = compute_classification_metrics(
        all_cls_probs, all_cls_targets, all_unc)

    return {**seg_metrics, **cls_metrics}
