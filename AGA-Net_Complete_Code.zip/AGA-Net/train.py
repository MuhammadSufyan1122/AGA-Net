"""
Main training script for AGA-Net Federated Learning.
Run with:
    python train.py --dataset synthetic --num_clients 8 --rounds 100

For real data (LUNA16 / LIDC-IDRI / NSCLC-Radiomics):
    python train.py --dataset luna16 --data_dir /path/to/luna16 \
                    --num_clients 8 --rounds 100
"""

import os
import sys
import json
import argparse
import random
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import random_split

# ── Local imports ──────────────────────────────────────────────
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from models.aga_net  import AGANet
from losses.aga_losses import AGANetLoss
from data.dataset    import (NoduleDataset, SyntheticNoduleDataset,
                              build_federated_loaders, build_eval_loader)
from utils.metrics   import evaluate_model


def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def parse_args():
    p = argparse.ArgumentParser(description='AGA-Net Federated Training')

    # Dataset
    p.add_argument('--dataset',     type=str,  default='synthetic',
                   choices=['synthetic', 'luna16', 'lidc_idri', 'nsclc'],
                   help='Dataset to use')
    p.add_argument('--data_dir',    type=str,  default='./data/luna16',
                   help='Root data directory (real datasets only)')
    p.add_argument('--patch_size',  type=int,  nargs=3, default=[64, 64, 64])
    p.add_argument('--n_synthetic', type=int,  default=400,
                   help='Samples for synthetic dataset')

    # Model
    p.add_argument('--base_filters', type=int, default=32)
    p.add_argument('--dropout_p',    type=float, default=0.3)
    p.add_argument('--mc_samples',   type=int, default=50,
                   help='Monte Carlo samples for uncertainty (inference)')
    p.add_argument('--num_classes',  type=int, default=2)

    # Federated
    p.add_argument('--num_clients',    type=int,   default=8)
    p.add_argument('--rounds',         type=int,   default=100)
    p.add_argument('--local_epochs',   type=int,   default=5)
    p.add_argument('--client_fraction',type=float, default=0.5)
    p.add_argument('--alpha_dir',      type=float, default=1.0,
                   help='Dirichlet concentration (lower=more non-IID)')
    p.add_argument('--aggregation',    type=str,   default='fedavg',
                   choices=['fedavg', 'fedprox', 'scaffold'])

    # Optimiser
    p.add_argument('--global_lr',    type=float, default=1e-4)
    p.add_argument('--local_lr',     type=float, default=5e-3)
    p.add_argument('--batch_size',   type=int,   default=8)
    p.add_argument('--weight_decay', type=float, default=1e-5)

    # Privacy
    p.add_argument('--epsilon',    type=float, default=8.0)
    p.add_argument('--delta',      type=float, default=1e-5)
    p.add_argument('--clip_bound', type=float, default=2.0)
    p.add_argument('--no_dp',      action='store_true',
                   help='Disable differential privacy')

    # Loss weights
    p.add_argument('--lam1', type=float, default=1.0)
    p.add_argument('--lam2', type=float, default=0.8)
    p.add_argument('--lam3', type=float, default=0.3)
    p.add_argument('--lam4', type=float, default=0.1)
    p.add_argument('--no_adaptive', action='store_true',
                   help='Use fixed loss weights (no adaptive scheme)')

    # Misc
    p.add_argument('--seed',           type=int,  default=42)
    p.add_argument('--device',         type=str,  default='auto')
    p.add_argument('--checkpoint_dir', type=str,  default='./checkpoints')
    p.add_argument('--log_every',      type=int,  default=10)
    p.add_argument('--eval_every',     type=int,  default=20)

    return p.parse_args()


def build_dataset(args):
    """Instantiate train/val/test datasets"""
    ps = tuple(args.patch_size)

    if args.dataset == 'synthetic':
        print(f"  Using SYNTHETIC dataset ({args.n_synthetic} samples)")
        full = SyntheticNoduleDataset(n_samples=args.n_synthetic,
                                       patch_size=ps,
                                       num_classes=args.num_classes,
                                       seed=args.seed)
        n      = len(full)
        n_tr   = int(0.70 * n)
        n_val  = int(0.15 * n)
        n_test = n - n_tr - n_val
        train_ds, val_ds, test_ds = random_split(
            full, [n_tr, n_val, n_test],
            generator=torch.Generator().manual_seed(args.seed))
        return train_ds, val_ds, test_ds

    else:
        print(f"  Using REAL dataset: {args.dataset} from {args.data_dir}")
        train_ds = NoduleDataset(args.data_dir, split='train', patch_size=ps)
        val_ds   = NoduleDataset(args.data_dir, split='val',   patch_size=ps,
                                  augment=False)
        test_ds  = NoduleDataset(args.data_dir, split='test',  patch_size=ps,
                                  augment=False)
        return train_ds, val_ds, test_ds


def main():
    args = parse_args()
    set_seed(args.seed)

    # ── Device ────────────────────────────────────────────────
    if args.device == 'auto':
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    else:
        device = torch.device(args.device)
    print(f"\n[Device] {device}")

    # ── Dataset ───────────────────────────────────────────────
    print("[Data] Loading datasets...")
    train_ds, val_ds, test_ds = build_dataset(args)
    print(f"  Train: {len(train_ds)} | Val: {len(val_ds)} | Test: {len(test_ds)}")

    # Build federated client loaders
    client_loaders = build_federated_loaders(
        train_ds,
        num_clients  = args.num_clients,
        alpha_dir    = args.alpha_dir,
        batch_size   = args.batch_size,
        seed         = args.seed
    )
    val_loader  = build_eval_loader(val_ds,  batch_size=args.batch_size)
    test_loader = build_eval_loader(test_ds, batch_size=args.batch_size)
    print(f"  Federated clients: {len(client_loaders)} "
          f"(α_dir={args.alpha_dir})")

    # ── Model ─────────────────────────────────────────────────
    print("[Model] Building AGA-Net...")
    model = AGANet(
        in_channels  = 1,
        num_classes  = args.num_classes,
        base_filters = args.base_filters,
        dropout_p    = args.dropout_p,
        mc_samples   = args.mc_samples
    )
    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"  Trainable parameters: {n_params/1e6:.1f}M")

    # ── Loss ──────────────────────────────────────────────────
    loss_fn = AGANetLoss(
        num_classes   = args.num_classes,
        init_weights  = (args.lam1, args.lam2, args.lam3, args.lam4),
        adaptive      = not args.no_adaptive,
        mu_fed        = 0.1,
        lam_dp        = 0.01
    )

    # ── Federated Trainer ─────────────────────────────────────
    print("[Federated] Initialising server...")

    # Import here to avoid circular import issues
    from federated.fl_trainer import FederatedServer

    server = FederatedServer(
        global_model     = model,
        loss_fn          = loss_fn,
        client_loaders   = client_loaders,
        val_loader       = val_loader,
        device           = device,
        num_rounds       = args.rounds,
        local_epochs     = args.local_epochs,
        client_fraction  = args.client_fraction,
        min_clients      = max(2, int(args.num_clients * 0.25)),
        global_lr        = args.global_lr,
        local_lr         = args.local_lr,
        weight_decay     = args.weight_decay,
        epsilon          = args.epsilon,
        delta            = args.delta,
        clip_bound       = args.clip_bound,
        use_dp           = not args.no_dp,
        aggregation      = args.aggregation,
        seed             = args.seed,
        log_every        = args.log_every,
        checkpoint_dir   = args.checkpoint_dir
    )

    # ── Train ─────────────────────────────────────────────────
    history = server.train()

    # Save history
    os.makedirs(args.checkpoint_dir, exist_ok=True)
    hist_path = os.path.join(args.checkpoint_dir, 'history.json')
    # Convert numpy types for JSON serialisation
    def _convert(obj):
        if isinstance(obj, (np.integer,)): return int(obj)
        if isinstance(obj, (np.floating,)): return float(obj)
        if isinstance(obj, list): return [_convert(o) for o in obj]
        return obj
    with open(hist_path, 'w') as fh:
        json.dump({k: _convert(v) for k, v in history.items()}, fh, indent=2)
    print(f"\n[History] Saved → {hist_path}")

    # ── Final Evaluation ──────────────────────────────────────
    print("\n[Evaluation] Running final test-set evaluation...")
    best_ckpt = os.path.join(args.checkpoint_dir, 'aga_net_final.pt')
    if os.path.exists(best_ckpt):
        ckpt = torch.load(best_ckpt, map_location=device)
        server.global_model.load_state_dict(ckpt['model_state'])

    test_metrics = evaluate_model(
        server.global_model, test_loader, device,
        mc_samples=args.mc_samples
    )

    print("\n" + "="*50)
    print("  FINAL TEST METRICS")
    print("="*50)
    for k, v in test_metrics.items():
        print(f"  {k:<15} {v:.4f}")

    results_path = os.path.join(args.checkpoint_dir, 'test_results.json')
    with open(results_path, 'w') as fh:
        json.dump({k: float(v) for k, v in test_metrics.items()}, fh, indent=2)
    print(f"\n[Results] Saved → {results_path}")


if __name__ == '__main__':
    main()
